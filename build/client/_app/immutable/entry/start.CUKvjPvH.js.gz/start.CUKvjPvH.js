import{l as o,a as r}from"../chunks/DPRDLum_.js";export{o as load_css,r as start};
